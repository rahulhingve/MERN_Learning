## React hook assignments
You will find a bunch of folders this week, each with some set of assignments for a specific hook
Go to the folder (for example 1-use-memo) and comment out the Assignment component you are working on (Assignment1/Assignment2...) and try to solve it
There are no tests, but solution videos will be provided